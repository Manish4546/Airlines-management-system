export class Airport{

  airportName:string;
  airportCode:string;
  airportLocation:string;
  action: boolean;
}
